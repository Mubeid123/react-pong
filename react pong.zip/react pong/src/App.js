import React, { Component, useState } from "react";
import Sketch from "react-p5";

import "p5/lib/addons/p5.sound";

import "./App.css";

import PubNub from "pubnub";
import { PubNubProvider, PubNubConsumer } from "pubnub-react";

import icePic from "./assets/ice.jpg";
import IcebergLeft from "./assets/IcebergL.png";
import IcebergRight from "./assets/IcebergR.png";
import firePic from "./assets//Fire.jpg";
import FireLeft from "./assets/FireL.png";
import FireRight from "./assets/FireR.png";
import tornadoPic from "./assets/Tornado.png";
import TornadoLeft from "./assets/TornadoL.png";
import TornadoRight from "./assets/TornadoR.png";
import music from "./assets/music.mp3";
// song = loadSound("assets/lucky_dragons_-_power_melody.mp3");

const PADDLE_WIDTH = 80;
const PADDLE_HEIGHT = 150;

var firstc = 4;
var secondc = 8;
var end = 15;


var fact1 = "Wildlife populations have dropped by 60 percent in over 40 years";
var fact2 = "Carbon emissions use are rising at the fastest rate since 2011";
var fact3 = "There’s more carbon dioxide in our atmosphere than any time in history";

var breadth = 10;
var length = 80;

var rectLscoreP;
var rectRscoreP;

// Player left
var rectL = {
	x: 20,
	y: 170,
};

// Player right
var rectR = {
	x: 570,
	y: 170,
};

// Ball
var ball = {
	x: 300,
	y: 200,
	durch: 30,
	wall: 20,
	speedX: 4,
	speedY: 3,
};
var ice,
	IceLeft,
	IceRight,
	Fire,
	FireL,
	FireR,
	Tornado,
	TornadoL,
	TornadoR,
	song;

const uuid = PubNub.generateUUID();
const pubnub = new PubNub({
	publishKey: "pub-c-0423734d-186c-4da3-b25d-dda4454e53bf",
	subscribeKey: "sub-c-43ab4374-f18b-11e9-9a2e-968ee626a36d",
	uuid: uuid,
});

export default class App extends Component {
	x = 50;
	y = 50;

	constructor(props) {
		super(props);
		this.myRef = React.createRef();
		this.state = {
			player1: 0,
			player2: 0,
		};
	}

	preload = (p5) => {
		p5.soundFormats("mp3", "ogg");
		song = p5.loadSound(music);
	};
	keyPressed = (p5) => { //When key is pressed, audio will be played in the background
		if (song) {
			if (!song.isPlaying()) {
				song.play();
			}
		}
	};

	getScore = (message) => {
		console.log("here getting scorews");
		pubnub.fetchMessages(
			{
				channels: ["pubnub_onboarding_channel"],
				count: 10,
			},
			(status, response) => {
				console.log(response);

				if (response) {
					if (
						response.channels.pubnub_onboarding_channel[
							response.channels.pubnub_onboarding_channel.length -
								1
						].message.player1
					) {
						if (window.rectLscore != rectLscoreP) {
							console.log("get player 1 score");

							this.setState({
								player1:
									response.channels.pubnub_onboarding_channel[
										response.channels
											.pubnub_onboarding_channel.length -
											1
									].message.player1,
							});

							rectLscoreP = window.rectLscore;
						}
					} else if (
						response.channels.pubnub_onboarding_channel[
							response.channels.pubnub_onboarding_channel.length -
								1
						].message.player2
					) {
						if (window.rectRscore != rectRscoreP) {
							console.log("get player 2 score");

							this.setState({
								player2:
									response.channels.pubnub_onboarding_channel[
										response.channels
											.pubnub_onboarding_channel.length -
											1
									].message.player2,
							});
							rectRscoreP = window.rectRscore;
						}
					}
				}
			}
		);
	};
	// SETUP
	setup = (p5, canvasParentRef) => {
		//initializating pictures
		ice = p5.loadImage(icePic);
		IceLeft = p5.loadImage(IcebergLeft);
		IceRight = p5.loadImage(IcebergRight);

		Fire = p5.loadImage(firePic);
		FireL = p5.loadImage(FireLeft);
		FireR = p5.loadImage(FireRight);

		Tornado = p5.loadImage(tornadoPic);
		TornadoL = p5.loadImage(TornadoLeft);
		TornadoR = p5.loadImage(TornadoRight);

		// console.log(this.song);
		p5.createCanvas(600, 400).parent(canvasParentRef);
		let cnv = p5.createCanvas(600, 400);
		cnv.position(365, 250, "fixed");

		window.rectLscore = 0;
		window.rectRscore = 0;

		rectLscoreP = 0;
		rectRscoreP = 0;
	};

	// DRAW FUNCTION
	draw = (p5) => {
		this.getScore();

		if (window.rectLscore == end || window.rectRscore == end) {
			window.rectLscore = 0;
			window.rectRscore = 0;
		}

		p5.background(0, 100, 255);

		// console.log(this.song);

		//Drawing images according to score
		if (window.rectLscore >= firstc || window.rectRscore >= firstc) {
			if (window.rectLscore >= secondc || window.rectRscore >= secondc) {
				p5.image(Tornado, 0, 0, 600, 400);
			} else {
				p5.image(Fire, 0, 0, 600, 400);
			}
		} else {
			p5.image(ice, 0, 0, 600, 400);
		}

		// draw scoreboard
		p5.fill(50, 205, 50);
		p5.text(
			"Player 1:  " +
				this.state.player1 +
				"  |  " +
				"Player 2:  " +
				this.state.player2,
			p5.width - 180,
			15
		);

		//Changing fact text with score
		p5.fill(255, 255, 255);
		if (window.rectLscore >= firstc || window.rectRscore >= firstc) {
			if (window.rectLscore >= secondc || window.rectRscore >= secondc) {
				p5.text(fact3, p5.width / 2.54, 390);
			} else {
				p5.text(fact2, p5.width / 2.54, 390);
			}
		} else {
			p5.text(fact1, p5.width / 2.54, 390);
		}

		// Playground
		p5.fill(255);
		// p5.stroke(200);
		p5.strokeWeight(2);
		p5.line(p5.width / 2, 0, p5.width / 2, p5.height);

		// p5.stroke(200);
		p5.strokeWeight(2);
		

		p5.noFill();
		// p5.stroke(0);
		p5.strokeWeight(4);
		p5.rect(2, 2, 596, 396);

		// Start
		// Ball
		p5.fill(0);
		p5.ellipse(ball.x, ball.y, ball.durch, ball.durch);

		// Player left and right
		p5.fill(0);
		p5.noStroke();

		//Changing left paddles with different stages
		if (window.rectLscore >= firstc || window.rectRscore >= firstc) {
			if (window.rectLscore >= secondc || window.rectRscore >= secondc) {
				p5.image(TornadoL, rectL.x, rectL.y, breadth, length);
			} else {
				p5.image(FireL, rectL.x, rectL.y, breadth, length);
			}
		} else {
			p5.image(IceLeft, rectL.x, rectL.y, breadth, length);
		}

		//Changing right paddles with different stages
		if (window.rectLscore >= firstc || window.rectRscore >= firstc) {
			if (window.rectLscore >= secondc || window.rectRscore >= secondc) {
				p5.image(TornadoR, rectR.x, rectR.y, breadth, length);
			} else {
				p5.image(FireR, rectR.x, rectR.y, breadth, length);
			}
		} else {
			p5.image(IceRight, rectR.x, rectR.y, breadth, length);
		}
		// p5.rect(rectR.x, rectR.y, br, len);

		// Movement
		// Player controls

		if (p5.keyIsDown(p5.UP_ARROW)) {
			rectR.y = rectR.y - 10;
		} else if (p5.keyIsDown(p5.DOWN_ARROW)) {
			rectR.y = rectR.y + 10;
		}

		if (p5.keyIsDown(87)) {
			rectL.y = rectL.y - 10;
		} else if (p5.keyIsDown(83)) {
			rectL.y = rectL.y + 10;
		}

		// Ball
		ball.x = ball.x + ball.speedX;
		ball.y = ball.y + ball.speedY;

		// console.log(ball.x);
		// console.log(PADDLE_WIDTH);
		//RIGHT PADDLE SCORE
		if (ball.x <= PADDLE_WIDTH) {
			window.rectRscore = window.rectRscore + 1;
		}

		//LEFT PADDLE SCORE
		if (ball.x >= p5.width) {
			window.rectLscore++;
		}

		// Borders
		// Rect borders
		if (rectR.y <= 0) {
			rectR.y = rectR.y + 10;
		} else if (rectR.y >= p5.height - length) {
			rectR.y = rectR.y - 10;
		}

		if (rectL.y <= 0) {
			rectL.y = rectL.y + 10;
		} else if (rectL.y >= p5.height - length) {
			rectL.y = rectL.y - 10;
		}

		// Ball borders
		if (ball.x >= p5.width) {
			ball.x = 300;
			ball.y = 200;
		} else if (ball.x <= ball.wall) {
			ball.x = 300;
			ball.y = 200;
		} else if (ball.y >= p5.height - ball.wall) {
			ball.speedY = ball.speedY * -1;
		} else if (ball.y <= 0 + ball.wall) {
			ball.speedY = ball.speedY * -1;
		}

		// Ball collides with Player
		if (
			ball.x >= rectR.x - ball.wall &&
			ball.y >= rectR.y &&
			ball.y <= rectR.y + length
		) {
			ball.speedX = ball.speedX * -1 - 0.2;
		} else if (
			ball.x <= rectL.x + ball.wall &&
			ball.y >= rectL.y &&
			ball.y <= rectL.y + length
		) {
			ball.speedX = ball.speedX * -1 + 0.2;
		}
	};

	render() {
		return (
			<Sketch
				preload={this.preload}
				setup={this.setup}
				draw={this.draw}
				keyPressed={this.keyPressed}
			/>
		);
	}
}
