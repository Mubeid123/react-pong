import React, { Component } from "react";
import Sketch from "react-p5";
import "./App.css";
import App from "./App";

let height = [];
let width = [];
let fill = [];
let noStroke = [];
let rect = [];
let round = [];
let random = [];
let ellipse = [];
let bounceSound = [];
let pointSound = [];
let leftScore = [];
let ball = [];
let rightScore = [];
let rightPuck = [];
let leftPuck = [];
let upCondition = [];
let downCondition = [];

class Ball {
	constructor() {
		// ball attributes
		this.x = width / 2;
		this.y = height / 2;
		this.diameter = 16;
		this.radius = this.diameter / 2;
		this.speeds = [-8, -7, -6, -5, 5, 6, 7, 8];
		this.xspeed = this.speeds[round(random(0, this.speeds.length - 1))];
		this.yspeed = this.speeds[round(random(0, this.speeds.length - 1))];
	}

	show() {
		// draw the ball
		fill(255, 0, 0);
		noStroke();
		ellipse(this.x, this.y, this.diameter, this.diameter);
	}

	update() {
		// move the ball
		this.x += this.xspeed;
		this.y += this.yspeed;
	}

	collision() {
		// manage collision behaviour, scores, and bounce/score sounds
		if (this.edges() && this.contact()) {
			bounceSound.play();
			this.xspeed *= -1;
			this.yspeed *= -1;
		} else if (this.edges() == true) {
			this.bounce("edge");
		} else if (this.edges() == "left point") {
			pointSound.play();
			leftScore += 1;
			ball = new Ball();
		} else if (this.edges() == "right point") {
			pointSound.play();
			rightScore += 1;
			ball = new Ball();
		} else if (this.contact() == true) {
			this.bounce("puck");
		} else if (this.contact() == "left point") {
			pointSound.play();
			leftScore += 1;
			ball = new Ball();
		} else if (this.contact() == "right point") {
			pointSound.play();
			rightScore += 1;
			ball = new Ball();
		}
	}

	edges() {
		//detect ball collisions with top or bottom bounds of world
		let worldUpperBound = this.radius;
		let worldLowerBound = height - this.radius;
		if (this.x <= 0) {
			return "right point";
		} else if (this.x >= width) {
			return "left point";
		}
		if (this.y <= worldUpperBound || this.y >= worldLowerBound) {
			return true;
		}
	}

	contact() {
		//detect ball collision with pucks
		let ballUpperBound = this.y - this.radius;
		let ballLowerBound = this.y + this.radius;

		let rightPuckUpperBound = rightPuck.y;
		let rightPuckLowerBound = rightPuck.y + rightPuck.height;

		let leftPuckUpperBound = leftPuck.y;
		let leftPuckLowerBound = leftPuck.y + leftPuck.height;

		if (
			ballUpperBound >= rightPuckUpperBound &&
			ballLowerBound <= rightPuckLowerBound
		) {
			if (this.x + this.radius >= rightPuck.x) {
				if (this.x + this.radius <= rightPuck.x + rightPuck.width / 2) {
					return true;
				} else {
					return "right point";
				}
			}
		}
		if (
			ballUpperBound >= leftPuckUpperBound &&
			ballLowerBound <= leftPuckLowerBound
		) {
			if (this.x - this.radius <= leftPuck.x + leftPuck.width) {
				if (this.x - this.radius >= leftPuck.x + leftPuck.width / 2) {
					return true;
				} else {
					return "right point";
				}
			}
		}
	}

	bounce(surface) {
		// calculate how ball should bounce off of colliding surface
		// simple elastic collision with edge, as edge has no velocity
		
		bounceSound.play();
		if (surface == "edge") {
			this.yspeed *= -1;
		} else if (surface == "puck") {
			if (upCondition == true) {
				// puck is moving upwards
				this.xspeed *= -1;
				this.ballDirection("up");
			} else if (downCondition == true) {
				// puck is moving downwards
				this.xspeed *= -1;
				this.ballDirection("down");
			} else {
				// puck isn't moving
				this.xspeed *= -1;
			}
		}
	}

	ballDirection(puckDir) {
		if (puckDir == "up") {
			if (this.yspeed < 0) {
				// ball moving "upwards"
				this.yspeed -= 2;
				this.xspeed -= 2;
			} else if (this.yspeed > 0) {
				// ball moving "downwards"
				this.yspeed -= 2;
				this.xspeed -= 2;
			}
		} else if (puckDir == "down") {
			if (this.yspeed < 0) {
				// ball moving "upwards"
				this.yspeed += 2;
				this.xspeed += 2;
			} else if (this.yspeed > 0) {
				// ball moving "downwards"
				this.yspeed += 2;
				if (this.xspeed) this.xspeed -= 2;
			}
		}
	}
}
