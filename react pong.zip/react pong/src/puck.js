import React, { Component } from "react";
import Sketch from "react-p5";
import "./App.css";
import App from "./App";

let height = [];
let width = [];
let fill = [];
let noStroke = [];
let rect = [];

class Puck {
	constructor(side) {
		// puck attributes
		this.side = side;
		this.width = 20;
		this.height = 150;
		this.yspeed = 0;
		this.direction = null;

		if (this.side == "left") {
			this.x = 25;
			this.y = height / 2 - this.height / 2;
		} else if (this.side == "right") {
			this.x = 735;
			this.y = height / 2 - this.height / 2;
		}
	}

	show() {
		// draw the pucks
		fill(255);
		noStroke();
		rect(this.x, this.y, this.width, this.height);
	}

	move(dir) {
		// manage the puck movements
		if (dir == "up" && this.y > 0) {
			this.y -= 10;
			//this.yspeed = -10;
		} else if (dir == "down" && this.y + this.height < height) {
			this.y += 10;
			// this.yspeed = 10;
		}
	}

	update() {
		if (this.y > 0 && this.y + this.height < height) {
			this.y += this.yspeed;
		} else if (this.y <= 0 && this.yspeed > 0) {
			this.y += this.yspeed;
		} else if (this.y + this.height >= height && this.yspeed < 0) {
			this.y += this.yspeed;
		}
	}
}

export default App;
